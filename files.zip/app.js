// ============================================================
// Fungsi murni — tidak menyentuh DOM, bisa diuji lewat Node:
//   node -e "require('./app.js')"
// ============================================================

function formatRupiah(angka) {
  const bulat = Math.round(Number(angka) || 0);
  return 'Rp' + bulat.toLocaleString('id-ID');
}

function hitungTotalTransaksi(jumlah, harga) {
  return (Number(jumlah) || 0) * (Number(harga) || 0);
}

function formatTanggalISO(tanggal) {
  const tahun = tanggal.getFullYear();
  const bulan = String(tanggal.getMonth() + 1).padStart(2, '0');
  const hari = String(tanggal.getDate()).padStart(2, '0');
  return `${tahun}-${bulan}-${hari}`;
}

function parseTanggalISO(iso) {
  const [tahun, bulan, hari] = iso.split('-').map(Number);
  return new Date(tahun, bulan - 1, hari);
}

// Mengisi nilai bawaan untuk field yang hilang/rusak, supaya data lama
// yang tersimpan di localStorage tetap bisa terbaca walau skema berubah.
function defaultTransaksi(t) {
  t = t || {};
  return {
    id: t.id || String(Date.now()) + Math.random().toString(16).slice(2),
    tanggal: t.tanggal || formatTanggalISO(new Date()),
    nama: t.nama && String(t.nama).trim() ? String(t.nama).trim() : '(tanpa nama)',
    jumlah: Number.isFinite(Number(t.jumlah)) && Number(t.jumlah) > 0 ? Number(t.jumlah) : 1,
    harga: Number.isFinite(Number(t.harga)) && Number(t.harga) >= 0 ? Number(t.harga) : 0,
  };
}

function awalMinggu(tanggal) {
  const hasil = new Date(tanggal);
  const hariKe = hasil.getDay(); // 0 = Minggu, 1 = Senin, ... 6 = Sabtu
  const geser = hariKe === 0 ? 6 : hariKe - 1; // jarak mundur ke hari Senin
  hasil.setDate(hasil.getDate() - geser);
  hasil.setHours(0, 0, 0, 0);
  return hasil;
}

function akhirMinggu(tanggal) {
  const mulai = awalMinggu(tanggal);
  const hasil = new Date(mulai);
  hasil.setDate(hasil.getDate() + 6);
  return hasil;
}

function transaksiPadaTanggal(daftar, tanggalISO) {
  return daftar.filter((t) => t.tanggal === tanggalISO);
}

function totalDaftarTransaksi(daftar) {
  return daftar.reduce((jumlah, t) => jumlah + hitungTotalTransaksi(t.jumlah, t.harga), 0);
}

const NAMA_HARI = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];

function rekapMingguan(daftar, tanggalAcuanISO) {
  const acuan = parseTanggalISO(tanggalAcuanISO);
  const mulai = awalMinggu(acuan);

  const perHari = [];
  for (let i = 0; i < 7; i++) {
    const hari = new Date(mulai);
    hari.setDate(hari.getDate() + i);
    const iso = formatTanggalISO(hari);
    perHari.push({
      tanggal: iso,
      label: NAMA_HARI[i],
      total: totalDaftarTransaksi(transaksiPadaTanggal(daftar, iso)),
    });
  }

  return {
    mulai: formatTanggalISO(mulai),
    selesai: formatTanggalISO(akhirMinggu(acuan)),
    perHari,
    total: perHari.reduce((jumlah, h) => jumlah + h.total, 0),
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    formatRupiah,
    hitungTotalTransaksi,
    defaultTransaksi,
    formatTanggalISO,
    parseTanggalISO,
    awalMinggu,
    akhirMinggu,
    transaksiPadaTanggal,
    totalDaftarTransaksi,
    rekapMingguan,
  };
}

// ============================================================
// Logika & UI — hanya berjalan di browser
// ============================================================
if (typeof document !== 'undefined') {
  (function () {
    const KUNCI_DATA = 'rekap-penjualan-data';
    const KUNCI_TEMA = 'rekap-tema';

    function muatTransaksi() {
      try {
        const mentah = localStorage.getItem(KUNCI_DATA);
        if (!mentah) return [];
        const diurai = JSON.parse(mentah);
        return Array.isArray(diurai) ? diurai.map(defaultTransaksi) : [];
      } catch (err) {
        console.error('Gagal membaca data penjualan:', err);
        return [];
      }
    }

    function simpanTransaksi(daftar) {
      localStorage.setItem(KUNCI_DATA, JSON.stringify(daftar));
    }

    function escapeHtml(teks) {
      const div = document.createElement('div');
      div.textContent = teks;
      return div.innerHTML;
    }

    function formatTanggalPendek(tanggal) {
      return tanggal.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
    }

    let transaksi = muatTransaksi();

    // --- Elemen ---
    const namaUsahaEl = document.getElementById('nama-usaha');
    const tombolMode = document.getElementById('tombol-mode');
    const ikonMode = document.getElementById('ikon-mode');

    const form = document.getElementById('form-transaksi');
    const inputTanggal = document.getElementById('input-tanggal');
    const inputNama = document.getElementById('input-nama');
    const inputJumlah = document.getElementById('input-jumlah');
    const inputHarga = document.getElementById('input-harga');
    const pratinjauTotal = document.getElementById('pratinjau-total');

    const pilihTanggalLihat = document.getElementById('pilih-tanggal-lihat');
    const daftarTransaksiEl = document.getElementById('daftar-transaksi');
    const kosongTransaksiEl = document.getElementById('kosong-transaksi');
    const totalHariIniEl = document.getElementById('total-hari-ini');

    const mingguSebelumnya = document.getElementById('minggu-sebelumnya');
    const mingguBerikutnya = document.getElementById('minggu-berikutnya');
    const labelMinggu = document.getElementById('label-minggu');
    const daftarRekapEl = document.getElementById('daftar-rekap');
    const totalMingguEl = document.getElementById('total-minggu');

    // --- Nama usaha dari tema.js ---
    if (typeof TEMA !== 'undefined' && TEMA.nama) {
      namaUsahaEl.textContent = TEMA.nama;
      document.title = TEMA.nama;
    }

    // --- Mode terang/gelap ---
    function terapkanMode(mode) {
      document.documentElement.setAttribute('data-mode', mode);
      tombolMode.setAttribute('aria-pressed', String(mode === 'gelap'));
      ikonMode.textContent = mode === 'gelap' ? '○' : '●';
    }

    const modeTersimpan = localStorage.getItem(KUNCI_TEMA) || (typeof TEMA !== 'undefined' ? TEMA.mode : 'terang');
    terapkanMode(modeTersimpan);

    tombolMode.addEventListener('click', () => {
      const modeBaru = document.documentElement.getAttribute('data-mode') === 'gelap' ? 'terang' : 'gelap';
      terapkanMode(modeBaru);
      localStorage.setItem(KUNCI_TEMA, modeBaru);
    });

    // --- Tanggal berjalan ---
    let tanggalDilihat = formatTanggalISO(new Date());
    let tanggalAcuanMinggu = tanggalDilihat;
    inputTanggal.value = tanggalDilihat;
    pilihTanggalLihat.value = tanggalDilihat;

    // --- Pratinjau total pada form ---
    function perbaruiPratinjau() {
      pratinjauTotal.textContent = formatRupiah(hitungTotalTransaksi(inputJumlah.value, inputHarga.value));
    }
    inputJumlah.addEventListener('input', perbaruiPratinjau);
    inputHarga.addEventListener('input', perbaruiPratinjau);
    perbaruiPratinjau();

    // --- Render daftar transaksi tanggal terpilih ---
    function renderDaftarTransaksi() {
      const transaksiHari = transaksiPadaTanggal(transaksi, tanggalDilihat)
        .slice()
        .sort((a, b) => (a.id > b.id ? 1 : -1));

      daftarTransaksiEl.innerHTML = '';
      kosongTransaksiEl.hidden = transaksiHari.length > 0;

      transaksiHari.forEach((t) => {
        const li = document.createElement('li');
        li.className = 'baris-ledger';
        li.innerHTML = `
          <div class="baris-ledger-info">
            <span class="baris-ledger-nama">${escapeHtml(t.nama)}</span>
            <span class="baris-ledger-detail">${t.jumlah} &times; ${formatRupiah(t.harga)}</span>
          </div>
          <span class="baris-ledger-total">${formatRupiah(hitungTotalTransaksi(t.jumlah, t.harga))}</span>
          <button type="button" class="tombol-hapus" data-id="${t.id}" aria-label="Hapus ${escapeHtml(t.nama)}">&times;</button>
        `;
        daftarTransaksiEl.appendChild(li);
      });

      totalHariIniEl.textContent = formatRupiah(totalDaftarTransaksi(transaksiHari));
    }

    // --- Render rekap mingguan ---
    function renderRekap() {
      const rekap = rekapMingguan(transaksi, tanggalAcuanMinggu);
      labelMinggu.textContent =
        `${formatTanggalPendek(parseTanggalISO(rekap.mulai))}–${formatTanggalPendek(parseTanggalISO(rekap.selesai))}`;

      daftarRekapEl.innerHTML = '';
      rekap.perHari.forEach((h) => {
        const li = document.createElement('li');
        li.className = 'baris-ledger baris-ledger--rekap';
        li.innerHTML = `
          <span class="baris-ledger-nama">${h.label}</span>
          <span class="baris-ledger-total">${formatRupiah(h.total)}</span>
        `;
        daftarRekapEl.appendChild(li);
      });

      totalMingguEl.textContent = formatRupiah(rekap.total);
    }

    function renderSemua() {
      renderDaftarTransaksi();
      renderRekap();
    }

    // --- Tambah transaksi ---
    form.addEventListener('submit', (peristiwa) => {
      peristiwa.preventDefault();
      const transaksiBaru = defaultTransaksi({
        tanggal: inputTanggal.value,
        nama: inputNama.value,
        jumlah: inputJumlah.value,
        harga: inputHarga.value,
      });
      transaksi.push(transaksiBaru);
      simpanTransaksi(transaksi);

      tanggalDilihat = transaksiBaru.tanggal;
      tanggalAcuanMinggu = tanggalDilihat;
      pilihTanggalLihat.value = tanggalDilihat;

      inputNama.value = '';
      inputJumlah.value = '1';
      inputHarga.value = '';
      perbaruiPratinjau();
      inputNama.focus();

      renderSemua();
    });

    // --- Hapus transaksi ---
    daftarTransaksiEl.addEventListener('click', (peristiwa) => {
      const tombol = peristiwa.target.closest('.tombol-hapus');
      if (!tombol) return;
      transaksi = transaksi.filter((t) => t.id !== tombol.dataset.id);
      simpanTransaksi(transaksi);
      renderSemua();
    });

    // --- Lihat tanggal lain ---
    pilihTanggalLihat.addEventListener('change', () => {
      tanggalDilihat = pilihTanggalLihat.value || formatTanggalISO(new Date());
      tanggalAcuanMinggu = tanggalDilihat;
      renderSemua();
    });

    // --- Navigasi minggu ---
    function geserMinggu(jumlahMinggu) {
      const acuan = parseTanggalISO(tanggalAcuanMinggu);
      acuan.setDate(acuan.getDate() + jumlahMinggu * 7);
      tanggalAcuanMinggu = formatTanggalISO(acuan);
      renderRekap();
    }
    mingguSebelumnya.addEventListener('click', () => geserMinggu(-1));
    mingguBerikutnya.addEventListener('click', () => geserMinggu(1));

    renderSemua();
  })();
}
