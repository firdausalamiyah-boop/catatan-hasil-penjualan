// Ubah nilai di sini untuk menyesuaikan dengan usahamu.
const TEMA = {
  nama: "Catatan Penjualan", // nama usaha, tampil di judul halaman
  mode: "terang" // "terang" atau "gelap" — dipakai jika belum ada pilihan tersimpan
};
